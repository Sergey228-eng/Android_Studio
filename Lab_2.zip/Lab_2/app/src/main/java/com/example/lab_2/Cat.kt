package com.example.lab_2

class Cat(name: String) : Animal(name), Voice {
    override fun makeSound(): String{
        var str = ""
        str = "$name meows"
        return str
    }

    override fun loudVoice(): String{
        var str = ""
        str = "$name meows loud"
        return str
    }

    override fun quietVoice(): String{
        var str = ""
        str = "$name meows quite"
        return str
    }
}