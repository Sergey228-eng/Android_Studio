package com.example.lab_2

class Fish(name: String) : Animal(name) {
    override fun makeSound(): String{
        var str = ""
        str = "$name can`t make sound:("
        return str
    }
}