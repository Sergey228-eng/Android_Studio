package com.example.lab_2

class Dog(name: String) : Animal(name), Voice {
    override fun makeSound(): String{
        var str = ""
        str = "$name barks"
        return str
    }

    override fun loudVoice(): String {
        var str = ""
        str = "$name barks loudly!"
        return str
    }

    override fun quietVoice(): String{
        var str = ""
        str = "$name squeaks quietly"
        return str
    }

}