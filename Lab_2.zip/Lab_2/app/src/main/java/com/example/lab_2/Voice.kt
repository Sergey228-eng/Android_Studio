package com.example.lab_2

interface Voice {
    fun loudVoice(): String
    fun quietVoice(): String
}