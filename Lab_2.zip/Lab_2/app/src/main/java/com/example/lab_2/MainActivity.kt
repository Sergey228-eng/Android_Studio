package com.example.lab_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.lab_2.R.*

class MainActivity : AppCompatActivity() {

    private var butt1: Button? = null
    private var butt2: Button? = null
    private var butt3: Button? = null
    private var butt4: Button? = null
    private var butt5: Button? = null
    private var butt6: Button? = null
    private var textResult: TextView? = null

    var choose = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_main)

        butt1 = findViewById(id.button)
        butt2 = findViewById(id.button2)
        butt3 = findViewById(id.button3)

        butt4 = findViewById(id.button4)
        butt5 = findViewById(id.button5)
        butt6 = findViewById(id.button6)

        textResult = findViewById(id.textView)

        var dog = Dog("Rex")
        var cat = Cat("Showy")
        var fish = Fish("Salmon")

        butt4?.setOnClickListener {
            choose = 1
            Toast.makeText(this, "name = Rex", Toast.LENGTH_LONG).show()
        }
        butt5?.setOnClickListener {
            choose = 2
            Toast.makeText(this, "name = Showy", Toast.LENGTH_LONG).show()
        }
        butt6?.setOnClickListener {
            choose = 3
            Toast.makeText(this, "name = Salmon", Toast.LENGTH_LONG).show()
        }

        butt1?.setOnClickListener {
            if(choose == 1) {
                var temp = dog.makeSound()
                textResult?.text = temp
            }
            if(choose == 2) {
                var temp = cat.makeSound()
                textResult?.text = temp
            }
            if(choose == 3) {
                var temp = fish.makeSound()
                textResult?.text = temp
            }
        }
        butt2?.setOnClickListener {
            if(choose == 1) {
                var temp = dog.loudVoice()
                textResult?.text = temp
            }
            if(choose == 2) {
                var temp = cat.loudVoice()
                textResult?.text = temp
            }
            if(choose == 3) {
                var temp = fish.makeSound()
                textResult?.text = temp
            }
        }
        butt3?.setOnClickListener {
            if(choose == 1) {
                var temp = dog.quietVoice()
                textResult?.text = temp
            }
            if(choose == 2) {
                var temp = cat.quietVoice()
                textResult?.text = temp
            }
            if(choose == 3) {
                var temp = fish.makeSound()
                textResult?.text = temp
            }
        }
    }
}