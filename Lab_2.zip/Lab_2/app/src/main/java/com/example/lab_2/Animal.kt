package com.example.lab_2

abstract class Animal(protected val name: String) {

    abstract fun makeSound(): String
}