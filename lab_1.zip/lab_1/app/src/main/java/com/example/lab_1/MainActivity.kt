package com.example.lab_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private var editTextTextPersonName: EditText? = null
    private var TextPassword: EditText? = null
    private var button: Button? = null
    private var textView: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextTextPersonName = findViewById(R.id.editTextTextPersonName)
        TextPassword = findViewById(R.id.TextPassword)
        button = findViewById(R.id.button)
        textView = findViewById(R.id.textView)

        button?.setOnClickListener{
            var name = editTextTextPersonName?.text.toString()
            var password = TextPassword?.text.toString()
            textView?.text = "Name = " + name + "\nPassword = " + password
        }

    }
}